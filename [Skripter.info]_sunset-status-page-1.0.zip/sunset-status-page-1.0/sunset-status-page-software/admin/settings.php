<?php
if ($_POST["header"]<>'') { 
$name = $_POST["header"];
$fp = fopen("includes/get-header.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["custom-color"]<>'') { 
$name = $_POST["custom-color"];
$fp = fopen("includes/get-header.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["logo"]<>'') { 
$name = $_POST["logo"];
$fp = fopen("includes/get-logo.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["favicon"]<>'') { 
$name = $_POST["favicon"];
$fp = fopen("includes/get-favicon.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["html"]<>'') { 
$name = $_POST["html"];
$fp = fopen("includes/get-html.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["css"]<>'') { 
$name = $_POST["css"];
$fp = fopen("includes/get-css.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["htitle"]<>'') { 
$name = $_POST["htitle"];
$fp = fopen("includes/get-htitle.php", "w");
$savestring = "$name";
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["banner"]<>'') { 
$name = $_POST["banner"];
$fp = fopen("includes/get-banner.php", "w");
$savestring = "$name";
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["title"]<>'') { 
$name = $_POST["title"];
$fp = fopen("includes/get-title.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["bg"]<>'') { 
$name = $_POST["bg"];
$fp = fopen("includes/get-bg.php", "w");
$savestring = "$name";
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["dcontact"]<>'') { 
$name = $_POST["dcontact"];
$fp = unlink("includes/get-email.php");
$savestring = "$name";
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["email"]<>'') { 
$name = $_POST["email"];
$fp = fopen("includes/get-email.php", "w");
$savestring = "$name";
fwrite($fp, $savestring);
fclose($fp);
}
?>

<?php
if (isset($_GET['new']))
{
	Service::add();
}

if (isset($_GET['delete']))
{
	Service::delete();
}

Template::render_header(_("Settings"), true);
?>
<div class="text-center">
	<h2>Settings</h2><br>
</div>
<?php 
if (isset($message)){
	?>
<p class="alert alert-danger"><?php echo $message; ?></p>
<?php }?>
   <?php
if ($_POST["header"]<>'') { 
echo "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">
Success! Changes have been saved.
  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
    <span aria-hidden=\"true\">&times;</span>
  </button>
</div>";
}
?>
    
    
<section style="background:white;padding:2em;box-shadow: 0 2px 3px 0 rgba(15, 31, 64, 0.12);margin-bottom:2em">
	<h3 class="pull-left"><i class="mdi mdi-eye"></i> Monitors</h3>
	<?php if ($user->get_rank() <= 1){?>
<button type="button" class="btn btn-inverse-dark btn-rounded btn-fw pull-right" data-toggle="modal" data-target="#monitor" style="border-radius:25px">
  <i class="mdi mdi-plus"></i> Add
</button>
<div class="modal fade" id="monitor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Monitor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="?do=settings&new=service" method="post">
		<div class="input-group new-service w-100">
			<input class="form-control" name="service" placeholder="Name" type="text" value="<?php echo ((isset($_POST['service']))?htmlspecialchars($_POST['service']):''); ?>" maxlength="50" required>
			<span class="input-group-btn">
				<button type="submit" class="btn btn-primary pull-right">CREATE</button>
			</span>
		</div>
	</form>
	A monitor is typically a server listing in which you'd like to post status incidents to. You can have multiple monitors, each referring to their own server/site.
      </div>
    </div>
  </div>
</div>


	<?php }?>
	<div class="table-responsive">
		<table class="table">
			
			<thead><tr>
				<?php if ($user->get_rank()<=1)
				{?>
					<?php } ?>
				</tr>
			</thead>
			<tbody>
				<?php 
				$query = $mysqli->query("SELECT *  FROM services");
				while($result = $query->fetch_assoc())
				{
					echo "<tr>";
					echo "<td>".$result['name']."</td>";
					if ($user->get_rank()<=1)
					{
						echo '<td><a href="'.WEB_URL.'/admin/?do=settings&delete='.$result['id'].'" class="pull-right btn btn-icons btn-inverse-danger"><i class="mdi mdi-delete"></i></a></td>';
					}
					echo "</tr>";
				}?>
			</tbody>
		</table>
	</div>
</section>

<section style="background:white;padding:2em;box-shadow: 0 2px 3px 0 rgba(15, 31, 64, 0.12);margin-bottom:2em">
	<h3 class="pull-left"><i class="mdi mdi-account-group"></i> Team </h3>
	<?php if ($user->get_rank() == 0){?> <a href="<?php echo WEB_URL;?>/admin/?do=new-user" class="btn btn-inverse-dark btn-rounded btn-fw pull-right"><i class="mdi mdi-plus"></i> Add</a><?php }?>
	<div class="table-responsive">
		<table class="table">
			
			<thead><tr><th scope="col"><?php echo _("Username");?></th><th scope="col"><?php echo _("Name");?></th><th scope="col"><?php echo _("Email");?></th><th scope="col"><?php echo _("Role");?></th></tr></thead>
			<tbody>
				<?php 
				$query = $mysqli->query("SELECT *  FROM users");
				while($result = $query->fetch_assoc())
				{
					echo "<tr>";
					echo "<td><a href='".WEB_URL."/admin/?do=user&id=".$result['id']."'>".$result['username']."</a></td>";
					echo "<td>".$result['name']." ".$result['surname']."</td>";
					echo "<td><a href=\"mailto:".$result['email']."\">".$result['email']."</a></td>";
					echo "<td>".$permissions[$result['permission']]."</td><td>";
					echo "</td>";
					echo "</tr>";
				}?>
			</tbody>
		</table>
	</div>
</section>

<?php if ($user->get_rank() <= 1){?>
<section style="background:white;padding:2em;box-shadow: 0 2px 3px 0 rgba(15, 31, 64, 0.12);margin-bottom:2em">
	<h3 class="pull-left"><i class="mdi mdi-tune"></i> Customization</h3><br><br><br>
	
	<div class="table-responsive">
		<table class="table">
			
		<form method="post">
Site Title:<br>
<input type="text" class="form-control" name="title" style="width:100%" value="<?php include 'includes/get-title.php'; ?>"><br><br>

Contact Email:<br>
<input type="email" class="form-control" name="email" style="width:100%" value="<?php include 'includes/get-email.php'; ?>">
<button type="submit" name="dcontact" class="btn btn-danger btn-outline"><i class="mdi mdi-delete"></i></button><br><br>

Primary Color:<br>
<input type="text" class="form-control jscolor {hash:true}" name="custom-color" value="<?php include 'includes/get-header.php'; ?>"><br><br>

Logo URL:<br>
<input type="url" class="form-control" name="logo" style="width:100%" value="<?php include 'includes/get-logo.php'; ?>"><br>
<img src="<?php include 'includes/get-logo.php'; ?>" alt="" width="100px"><br><br>

Favicon URL:<br>
<input type="url" class="form-control" name="favicon" style="width:100%" value="<?php include 'includes/get-favicon.php'; ?>"><br>
<img src="<?php include 'includes/get-favicon.php'; ?>" width="30px" alt=""><br><br>

Description:<br>
<textarea name="banner" class="form-control" rows="7"><?php include 'includes/get-banner.php'; ?></textarea><br><br>


  <div class="form-row">
    <div class="col">
      Headline:<br>
<input type="text" name="htitle" class="form-control" value="<?php include 'includes/get-htitle.php'; ?>">
    </div>
    <div class="col">
      Background:<br>
<select name="bg" class="form-control">
  <option value="<?php include 'includes/get-bg.php'; ?>">Select...</option>
  <option value="https://d1v3uce98qr32f.cloudfront.net/knowledge-base-pattern-1.png">Pattern 1</option>
  <option value="https://d1v3uce98qr32f.cloudfront.net/knowledge-base-pattern-2.png">Pattern 2</option>
  <option value="https://d1v3uce98qr32f.cloudfront.net/knowledge-base-pattern-3.png">Pattern 3</option>
  <option value="https://d1v3uce98qr32f.cloudfront.net/knowledge-base-pattern-4.png">Pattern 4</option>
</select>
    </div>
  </div>



Custom HTML:<br>
<textarea id="codesnippet_editable" name="html" class="form-control" rows="15"><?php include 'includes/get-html.php'; ?></textarea>
<br>
   <input type="submit" class="btn btn-default btn-success btn-block" value="Save Changes">

</form>
		</table>
	</div>
</section>
	<?php }?>
<style>
    textarea {
  width: 100%;
}
</style>