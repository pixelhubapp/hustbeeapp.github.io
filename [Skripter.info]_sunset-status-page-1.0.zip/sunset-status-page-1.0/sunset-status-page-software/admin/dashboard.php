<?php 
$offset = 0;
if (isset($_GET['ajax']))
{
  $constellation->render_incidents(false,$_GET['offset'],5);
  exit();
}else if (isset($_GET['offset']))
{
  $offset = $_GET['offset'];
}
if (isset($_GET['new']) && $_GET['new']=="incident")
{
  Incident::add();
}
if (isset($_GET['delete']))
{
  Incident::delete($_GET['delete']);
}
Template::render_header(_("Incidents"), true); 
?>
        <style>
            
select#type {
   -webkit-appearance: button;
   -webkit-border-radius: 2px;
   -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
   -webkit-padding-end: 20px;
   -webkit-padding-start: 2px;
   -webkit-user-select: none;
   background-image: url(arrow.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 40%, #E5E5E5);
   background-position: 97% center;
   background-repeat: no-repeat;
   border: 1px solid #AAA;
   color: #555;
   font-size: inherit;
   margin-left: 0px;
   overflow: hidden;
   padding: 5px 10px;
   text-overflow: ellipsis;
   white-space: nowrap;
}
.panel-title {
    color:white;
}
.timeago {
    color:white;
}
        </style>
        
        <div class="jumbotron"  style="background:transparent;border:5px solid #ff6c54;box-shadow: 0 2px 3px 0 rgba(15, 31, 64, 0.12);">
            <h1 style="margin-bottom:.4em;"><i class="mdi mdi-white-balance-sunny"></i> Hello <?php printf($user->get_name());?>!</h1>
            <p>Experiencing an issue? Planning maintenance? Create an incident to let your users know what's happening.</p>
<button type="button" class="btn btn-inverse-warning" style="margin-top:1em" id="new-btn" data-toggle="modal" data-target="#incident">
  <i class="fa fa-plus"></i>&nbsp;&nbsp; Create New Incident
</button>
</div>

<div class="modal fade" id="incident" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Incident</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <div id="current">
    <?php
    $services = $constellation->render_status(true);
    ?>
    
          <form id="new-incident" action="<?php echo WEB_URL;?>/admin/?new=incident" method="POST" class="clearfix">
        <div class="panel">
          <?php if (isset($message))
          {?>
          <p class="alert alert-danger"><?php echo $message?></p>
          <?php
          } ?>
          <div id="status-container" class="clearfix">
          <?php 
          if (isset($_POST['services']) && !is_array($_POST['services']))
          {
            $post_services = array($_POST['services']);
          }else{
            $post_services = array();
          }
          foreach($services as $service){
          ?>
            <div class="item clearfix">
              <div class="service"><?php if ($service->get_status()!=-1){?><input type="checkbox" name="services[]" value="<?php echo $service->get_id(); ?>" <?php echo (in_array($service->get_id(), $post_services))?"checked":'';?> id="service-<?php echo $service->get_id(); ?>"><?php } ?> <label for="service-<?php echo $service->get_id(); ?>"><?php echo $service->get_name(); ?></label></div>
              <div class="status <?php if ($service->get_status()!=-1){echo $classes[$service->get_status()];}?>"><div style="color:black">Status: </div><?php if ($service->get_status()!=-1){echo $statuses[$service->get_status()];}?></div>
            </div>
          <?php
          }
          ?>
          </div>
        </div>
        
        <select class="form-control w-100" id="type" name="type">
            <?php 
            if (isset($_POST['type']))
            {
              $selected_status = $_POST['type'];
            }else
            {
              $selected_status = 2;
            }
            foreach ($statuses as $key => $value) {
              echo '<option value="'.$key.'"'.(($key==$selected_status)?' selected':'').'>'.$value.'</option>';
            }
            ?>
          </select><br>
        
          <div class="panel new panel-primary">
            <div class="panel-heading hide">
              <i class="glyphicon glyphicon-info-sign"></i>
            </div>
            
            <div class="panel-heading clearfix">
              <input type="text" name="title" id="title" placeholder="<?php echo _("Title");?>" value="<?php echo (isset($_POST['title'])?htmlspecialchars($_POST['title']):''); ?>" required> <span id="time"><input id="time_input" type="text" pattern="(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))" name="time" value="<?php echo (isset($_POST['time'])?htmlspecialchars($_POST['time']):''); ?>" class="pull-right" placeholder="<?php echo _("Time");?>">
                <input id="time_input_js" name="time_js" type="hidden" class="pull-right">
              </span>
            </div>
            <div class="panel-body">
              <textarea name="text" placeholder="Message" required><?php echo (isset($_POST['text'])?htmlspecialchars($_POST['text']):''); ?></textarea>
            </div>
            <div class="panel-footer clearfix">
              <small><span id="end_time_wrapper"><?php echo _("Ending");?>:&nbsp;<input id="end_time" type="text" pattern="(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))" name="end_time" class="pull-right" placeholder="<?php echo _("End time");?>" value="<?php echo (isset($_POST['end_time'])?htmlspecialchars($_POST['end_time']):''); ?>"></span></small>
              <input id="end_time_js" name="end_time_js" type="hidden" class="pull-right">
            </div>
          </div>
          <button type="submit" class="btn btn-success btn-block">PUBLISH</button>
        </form>
        
        
  </div>
      </div>
    </div>
  </div>
</div>


  
  <style>
      #status-big {
          display:none;
      }
      .hide {
          display:none;
  </style>
  
    <div class="item">
        <div class="line text-muted"></div>
         <?php
            $constellation->render_incidents(true,$offset,5,true);
            $constellation->render_incidents(false,$offset,5,true);
          ?>
      </div>
    </div>
  </div>