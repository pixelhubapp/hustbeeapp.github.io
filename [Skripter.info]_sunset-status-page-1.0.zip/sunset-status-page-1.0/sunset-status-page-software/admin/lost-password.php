
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Reset Password | Sunset</title>
  <link rel="stylesheet" href="<?php echo WEB_URL;?>/css/default.css">
  <link rel="shortcut icon" href="https://myhexa.co/sunset-favicon.ico" />
</head>
<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
        <div class="row w-100 mx-auto">
          <div class="col-lg-4 mx-auto">
            <div class="auto-form-wrapper">
                <center><img src="https://myhexa.co/assets/img/sunset-full.png" alt="Sunset" width="200px"></center>

                 <?php
    if (isset($_POST['id']))
    {
        $user = new User($_POST['id']);
        $user->change_password($_POST['token']);
        if (isset($message)){?>
        <p class="alert alert-danger"><?php echo $message?></p>
        <a href="<?php echo WEB_URL;?>/admin/?do=lost-password<?php echo "&id=".$_POST['id']."&token=".$_POST['token'];?>"><?php echo _("Go back");?> </a>
        <?php 
        }
        else{?>
        <p class="alert alert-success">Success! Your password has been changed.</p>
        <center><a href="<?php echo WEB_URL;?>/admin/">Continue to login</a></center>
        <?php 
        }
    }
    else if (isset($_POST['email']))
    {
      User::password_link();
      if (isset($message)){?>
      <p class="alert alert-danger"><?php echo $message?></p>
      <a href="<?php echo WEB_URL;?>/admin/?do=lost-password"><?php echo _("Go back to start");?></a>
      <?php 
      }
        else{?>
        <br><p class="alert alert-success">Success! Please check your email to reset your password.</p><br>
        <center><a href="<?php echo WEB_URL;?>/admin/"><?php echo _("Go back to login page");?></a></center>
        <?php 
      }
    }
    else{

      if (isset($message)){?>
      <p class="alert alert-danger"><?php echo $message?></p>
      <?php }?>
      <form method="post"><br><br>
      <?php if (!isset($_GET['id'])||!isset($_GET['token'])){?>
      <div class="form-group">
                  <label class="label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="john@gmail.com" required>
                </div>
					<div class="container-login100-form-btn">
						<button type="submit" class="btn submit-btn btn-block" style="background:#ff6c54;color:white">
							Reset Password
						</button>
					</div>
            </span>
        <?php }
        else{
          $user = new User($_GET['id']);
          ?>
            <input type="hidden" name="id" value="<?php echo $_GET['id'];?>" >
            <input type="hidden" name="token" value="<?php echo $_GET['token'];?>" >
            
            			<div class="wrap-input100 validate-input m-b-35" data-validate = "This field is required">
						<input class="input100" type="password" name="password" id="new_password" required>
						<span class="focus-input100" data-placeholder="New Password"></span>
					</div>
					
					    <div class="wrap-input100 validate-input m-b-35" data-validate = "This field is required">
						<input class="input100" type="password" name="password_repeat" id="new_password_check" required>
						<span class="focus-input100" data-placeholder="Repeat Password"></span>
					</div>
					
					<div class="container-login100-form-btn">
						<button type="submit" class="login100-form-btn">
							Change Password
						</button>
					</div>
          <?php 
        }
        ?>
		<br/> 
		<center><a href="<?php echo WEB_URL;?>/admin">Back to login</button></center>

        </form>
        <?php }?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>


 