
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Log In | Sunset</title>
  <link rel="stylesheet" href="<?php echo WEB_URL;?>/css/default.css?<?php echo rand(5, 15); ?>">
  <link rel="shortcut icon" href="https://myhexa.co/sunset-favicon.ico" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/2.6.95/css/materialdesignicons.css" />
</head>
<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
        <div class="row w-100 mx-auto">
          <div class="col-lg-4 mx-auto">
            <div class="auto-form-wrapper">
                <center><img src="https://myhexa.co/assets/img/sunset-full.png" alt="Sunset" width="200px" style="margin-bottom:2em"></center>
              <form method="post">
                  <?php if (isset($message)){?>
    <p class="alert alert-danger"><?php echo $message?></p>
    <?php }else{?>
    <?php }?>
                <div class="form-group">
                  <label class="label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="john@gmail.com" required>
                </div>
                <div class="form-group">
                  <label class="label">Password</label>
                    <input type="password" name="pass" class="form-control" placeholder="*********" required>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-inverse-dark btn-fw btn-block">Login <i class="mdi mdi-arrow-right"></i></button><br>
                </div>
                <div class="form-group d-flex justify-content-between">
                  <div class="mt-0">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="remember" id="remember" checked>
                      Keep me signed in
                    </label>
                  </div>
                  <a href="?do=lost-password" class="text-small forgot-password text-black">Forgot Password</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>$(".form-check .form-check-label,.form-radio .form-check-label").not(".todo-form-check .form-check-label").append('<i class="input-helper"></i>');</script>
</body>

</html>