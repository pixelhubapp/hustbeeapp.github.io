<?php 

class Template{

  public static function render_header($page_name, $admin = false){
    if (!$admin)
    {
      ?>
      <!doctype html>
      <html lang="en">
      <head>
        <meta charset="utf-8">
        <title>Status | <?php include './admin/includes/get-title.php'; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="View <?php include './admin/includes/get-title.php'; ?> server uptime and see when something goes wrong. Powered by Sunset.">
        <link rel="shortcut icon" href="<?php include './admin/includes/get-favicon.php'; ?>" type="image/png">
        <link rel="stylesheet" href="<?php echo WEB_URL;?>/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo WEB_URL;?>/css/main.css" media="screen">
        <link rel="stylesheet" href="<?php echo WEB_URL;?>/css/print.css" media="print">
        <link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
        <style>
        body {
            font-family: 'Muli', sans-serif;
           background-image: url("<?php include './admin/includes/get-bg.php'; ?>");
           background-color: <?php include './admin/includes/get-header.php'; ?>;
           background-attachment:fixed;
        }
        .item h3 {
            color:lightgray;
        }
        
        center img {
            display:none;
        }
        center h3 {
            margin-top:2em;
        }
        </style>
      </head>
      <body>


          <!--Custom CSS-->
          <style>
            <?php include './admin/includes/get-css.php'; ?>
            </style>
            <!-- End Custom CSS -->
          
        <div class="navbar navbar-default" role="navigation" style="background-color:transparent">
          <div class="container">
            <div class="navbar-header">
              <a class="navbar-brand" href="<?php echo WEB_URL;?>"><img src="<?php include './admin/includes/get-logo.php'; ?>" alt="" class="menu-logo" width="130" style="margin-top:.65em"></a>
            </div>
            
            <?php if (!file_exists("./admin/includes/get-email.php")) {
    echo "<style>#nav-right {display:none}</style>"; } ?>
    
<ul id="nav-right" class="nav navbar-nav navbar-right">
      <li><button onclick="window.location.href='mailto:<?php include './admin/includes/get-email.php'; ?>';" class="btn btn-default" style="border:none;width:150px;height:50px;outline:none;">Contact Us</button></li>
    </ul>
          </div>
        </div><br><br><br>
        
        <center><h1 style="color:#fff;font-weight:bold;font-size:65px;line-height:1.22;max-width:740px;margin-left:auto;margin-right:auto;margin-bottom:.5em;font-family: 'Muli', sans-serif;"><?php include './admin/includes/get-htitle.php'; ?></h1>
        
        <p style="color:#fff;font-weight:normal;font-size:16px;line-height:1.22;max-width:740px;margin-left:auto;margin-right:auto;margin-bottom:1em;font-family: 'Muli', sans-serif;"><?php include './admin/includes/get-banner.php'; ?></p></center><br>
        
        <div id="wrapper" class="center" style="max-width: 700px;background-color: #F7F8FA;padding:1em;padding-left:3em;padding-right:3em;border-radius:10px;box-shadow: 0 2px 3px 0 rgba(15, 31, 64, 0.12);margin-bottom:5em"><br>
            
            <!--Custom HTML-->
            <?php include './admin/includes/get-html.php'; ?>
            
            <!-- End Custom HTML -->
            
    <?php 
      }else{
        global $user;
        ?>
        <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="icon" type="image/png" href="https://myhexa.co/sunset-favicon.ico">
    <title><?php echo $page_name ?> | Sunset</title>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.25/daterangepicker.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo WEB_URL;?>/css/default.css?<?php echo rand(5, 15); ?>" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/2.6.95/css/materialdesignicons.css" />
<link href="<?php echo WEB_URL;?>/css/jquery.growl.css" rel="stylesheet">
    <link href="<?php echo WEB_URL;?>/css/main.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
</head>
<style>
<?php if ($admin){?>
#footerwrap {
    display:none;
}
<?php }?>

#wrapper
{
	max-width: 900em;
	min-height: calc(0vh - 0px);
	padding-right: 0px;
	padding-left: 0px
}
.modal-backdrop
{
    opacity:0.5 !important;
}
</style>
<body class="sidebar-dark sidebar-expand navbar-brand-dark header-light">
    <div id="wrapper" class="wrapper">
        
            <nav class="navbar horizontal-layout col-lg-12 col-12 p-0">
      <div class="container d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-top">
          <a class="navbar-brand brand-logo" href="index.html"><img src="https://myhexa.co/assets/img/sunset-full.png" alt="Sunset"/></a>
          <a class="navbar-brand brand-logo-mini" href="index.html"><img src="icon_colored.png" alt="Sunset"/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center">
          <div class="ml-auto"></div>
          <ul class="navbar-nav navbar-nav-right mr-0">
            
              
                <a href="<?php echo WEB_URL;?>/admin/?do=user" class="dropdown-item">
                  <i class="list-icon mdi mdi-account"></i> Profile
                </a>
                <a href="<?php echo WEB_URL;?>/admin/?do=logout" class="dropdown-item">
                 <i class="list-icon mdi mdi-logout"></i> Logout
                </a>
            
          </ul>
          <button class="navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </div>
      <div class="nav-bottom">
        <div class="container">
          <ul class="nav page-navigation">
            <li class="nav-item">
              <a href="<?php echo WEB_URL;?>/admin/" class="nav-link"><span class="menu-title"><i class="mdi mdi-alert"></i> Incidents</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo WEB_URL;?>/admin/?do=settings" class="nav-link"><span class="menu-title"><i class="list-icon mdi mdi-settings"></i> Settings</span></a>
            </li>
            <li class="nav-item">
              <a href="<?php echo WEB_URL;?>" target="_blank" class="nav-link"><span class="menu-title"><i class="list-icon mdi mdi-open-in-new"></i> Visit Site</span></a>
            </li>
            
                </div>
              </div>
            </li>
        
          </ul>
        </div>
      </div>
    </nav>
    
    
        <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
    <div class="content-wrapper">
    

      <?php 
    }
  }

  public static function render_footer($admin = false)
  {
    global $negotiator;
    $lang_names = $negotiator->get_accepted_langs();
    ?>
    </div>
    
    <div id="footerwrap" style="background-color:transparent">
      <div class="container">
        <div class="row">
          <div class="col-md-4 text-left">© <?php echo date("Y");?> <?php include './admin/includes/get-title.php'; ?></div>
          <div class="text-right"><a href="https://gosunset.co" target="_blank"><img src="https://myhexa.co/assets/img/sunset-light.png" width="70px" title="Easily create and manage awesome status pages for free"></a></div>
        </div>
      </div>
    </div>
    <script src="<?php echo WEB_URL;?>/js/vendor/jquery-3.2.1.min.js"></script>
    <script src="<?php echo WEB_URL;?>/js/vendor/jquery.timeago.js"></script>
    <script src="<?php echo WEB_URL;?>/locale/<?php echo $_SESSION['locale'];?>/jquery.timeago.js"></script>
    <?php if ($admin){?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="<?php echo WEB_URL;?>/js/admin.js"></script>
    <script src="<?php echo WEB_URL;?>/js/vendor/jquery.growl.js"></script>
    <script src="<?php echo WEB_URL;?>/js/vendor/bootstrap.min.js"></script>
    <script src="<?php echo WEB_URL;?>/js/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.2/umd/popper.min.js"></script>
    <script src="<?php echo WEB_URL;?>/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.7.0/metisMenu.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/js/perfect-scrollbar.jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/countup.js/1.9.2/countUp.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.2/circle-progress.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.25/daterangepicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mithril/1.1.1/mithril.js"></script>
    <script src="<?php echo WEB_URL;?>/js/widgets.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo WEB_URL;?>/js/theme.js"></script>
    <script src="<?php echo WEB_URL;?>/js/custom.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jscolor/2.0.4/jscolor.min.js"></script>
    <?php }?>
    </body>
  </html>
<?php
  }
}