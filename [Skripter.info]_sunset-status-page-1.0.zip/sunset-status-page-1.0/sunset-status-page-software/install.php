<?php
if (file_exists('config.php')) {
header("Location: $url");
exit;
}

if ($_POST["title"]<>'') { 
$name = $_POST["title"];
$fp = fopen("admin/includes/get-title.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["logo"]<>'') { 
$name = $_POST["logo"];
$fp = fopen("admin/includes/get-logo.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["color"]<>'') { 
$name = $_POST["color"];
$fp = fopen("admin/includes/get-header.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}

if ($_POST["banner"]<>'') { 
$name = $_POST["banner"];
$fp = fopen("admin/includes/get-banner.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["iemail"]<>'') { 
$name = $_POST["iemail"];
$fp = fopen("admin/includes/get-email.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["favicon"]<>'') { 
$name = $_POST["favicon"];
$fp = fopen("admin/includes/get-favicon.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["htitle"]<>'') { 
$name = $_POST["htitle"];
$fp = fopen("admin/includes/get-htitle.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["html"]<>'') { 
$name = $_POST["html"];
$fp = fopen("admin/includes/get-html.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}
if ($_POST["cemail"]<>'') { 
$name = $_POST["cemail"];
$fp = fopen("admin/includes/get-email.php", "w");
$savestring = $name;
fwrite($fp, $savestring);
fclose($fp);
}

$url = filter_var($_POST["url"], FILTER_SANITIZE_URL);
if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
      $url = "http://" . $url;
  }
  $url = rtrim($url,"/");

$url = $_POST["url"];

$uemail = $_POST["uemail"];

$uusername = $_POST["uusername"];

$ufirst = $_POST["ufirst"];

$ulast = $_POST["ulast"];



$email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

$website_name = filter_var($_POST["website_name"], FILTER_SANITIZE_STRING);

$db_name = $_POST["db_name"];

$db_user = $_POST["db_user"];

$db_password = $_POST["db_password"];

$db_host = $_POST["db_host"];

$db_charset = "utf8";

$db_type = "mysql";

$cookie = GenerateString(1900);

$key = GenerateString(35);

$sql = "
SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = \"+00:00\";
CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
INSERT INTO `services` (`id`, `name`) VALUES
(7, 'Cloud Services'),
(8, 'Website');
CREATE TABLE `services_status` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
INSERT INTO `services_status` (`id`, `service_id`, `status_id`) VALUES
(12, 7, 9);
CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `text` text COLLATE utf8_czech_ci NOT NULL,
  `time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
INSERT INTO `status` (`id`, `type`, `title`, `text`, `time`, `end_time`, `user_id`) VALUES
(9, 3, 'Test', 'Just Testing!', 1530638148, 0, 2);
CREATE TABLE `tokens` (
  `token` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `user` int(11) NOT NULL,
  `expire` int(11) NOT NULL,
  `data` varchar(80) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
INSERT INTO `tokens` (`token`, `user`, `expire`, `data`) VALUES
('2f3b00ed50d1a7aa6d87c41b2e5c25782181ef840cf8aa9d7d33e683ac107ba6', 2, 1561390376, 'remember'),
('3858272963d1672ad1fe8cc5531afb92e51470d637a9d57fb561930bd076e827', 1, 1561557869, 'remember'),
('6ca8e110136067eba54211da7390eef59de5bbda6887ff0850e171241a4cae7a', 1, 1560091269, 'remember'),
('b8c0010db51414a42406f388e60a46024ffe53c949ed53c029a03dab3f1a09ff', 1, 1560180657, 'remember'),
('c1ad35325aa7c9ba7507ee38bbee2144ba1c79385c95847ecec7e453214a342c', 2, 1561269529, 'remember');
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(60) COLLATE utf8_czech_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `surname` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `password_hash` char(64) COLLATE utf8_czech_ci NOT NULL,
  `password_salt` char(64) COLLATE utf8_czech_ci NOT NULL,
  `permission` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
INSERT INTO `users` (`id`, `email`, `username`, `name`, `surname`, `password_hash`, `password_salt`, `permission`, `active`) VALUES
(3, '$uemail', '$uusername', '$ufirst', '$ulast', '7c812127b525f9f20b72beef755d81badc8e8e0c52346cdc50fe7b57be99c629', '3474304935b3d2a8c421575.58997290', 0, 1);
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `services_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `status_id` (`status_id`);
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`token`),
  ADD KEY `user` (`user`);
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
ALTER TABLE `services_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
ALTER TABLE `services_status`
  ADD CONSTRAINT `service_id` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  ADD CONSTRAINT `status_id` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`);
ALTER TABLE `status`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
ALTER TABLE `tokens`
  ADD CONSTRAINT `user` FOREIGN KEY (`user`) REFERENCES `users` (`id`);
COMMIT;";

$config = '<?php

session_start();

define("WEB_URL", "'.$url.'");

define("MAILER_NAME", "Sunset");

define("MAILER_ADDRESS", "no-reply@myhexa.co");

define("DEFAULT_LANGUAGE", "en_GB");

require("classes/locale-negotiator.php");

$negotiator = new LocaleNegotiator(DEFAULT_LANGUAGE);

if (!isset($_SESSION[\'locale\'])||isset($_GET[\'lang\']))
{
	$override = ((isset($_GET[\'lang\']))?$_GET[\'lang\']:null);
	$best_match = $negotiator->negotiate($override);
	$_SESSION[\'locale\'] = $best_match;
}

setlocale(LC_ALL, $_SESSION[\'locale\'].".UTF-8");
setlocale(LC_MESSAGES, $_SESSION[\'locale\'].".UTF-8");
bindtextdomain("server-status", __DIR__ . "/locale/");
bind_textdomain_codeset("server-status", "utf-8"); 
textdomain("server-status");

$mysqli = new mysqli("'.$db_host.'","'.$db_user.'","'.$db_password.'","'.$db_name.'");

if ($mysqli->connect_errno) {
    printf(_("Connection failed: %s\n"), $mysqli->connect_error);
    exit();
}

$mysqli->set_charset("utf8");

$statuses = array(_("<i class=\"fas fa-times-circle\" title=\"Service is experiencing a major outage\"></i>"), _("<i class=\"fas fa-exclamation-circle\" title=\"Service is experiencing a minor outage\"></i>"),_("<i class=\"fas fa-flag\" title=\"Service is undergoing maintenance\"></i>"),_("<i class=\"fas fa-check\" title=\"Service is Operational\"></i>") );
    
    
$classes = array("danger","warning", "primary", "success" );
    
    
$icons = array("fa fa-times", "fa fa-exclamation", "fa fa-info", "fa fa-check" );
    
$some = array( _("<i class=\"fas fa-times\"></i> Some systems are experiencing major outages"),_("<i class=\"fas fa-exclamation-circle\"></i> Some systems are experiencing minor outages"), _("<i class=\"fas fa-flag\"></i> Some systems are under maintenance"));
    
$all = array(_("<i class=\"fas fa-times\"></i> Our systems are experiencing major outages."),_("<i class=\"fas fa-exclamation-circle\"></i> Our systems are experiencing minor outages"),_("<i class=\"fas fa-flag\"></i> Our systems are under maintenance"), _("<i class=\"fas fa-check\"></i> All services are operational"));
    
$permissions = array(_("Super admin"),_("Admin"),_("Editor"));

?>';
function GenerateString($length = 6) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
if(!empty($db_name)) {
  require_once("dbconnect.php");
  $global_database = new dbConnect(['database_type' => $db_type,'database_name' => $db_name,'server' => $db_host,'username' => $db_user,'password' => $db_password,'charset' => $db_charset]);
  $global_database->query($sql);
  file_put_contents("config.php", $config);
  header("Location: /admin/");
  exit;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Auto-Installer | Sunset</title>
        <link rel="shortcut icon" href="https://myhexa.co/sunset-favicon.ico" />
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="https://demo.myhexa.co/short/admin/install_assets/bootstrap/css/bootstrap.min.css?<?php echo(mt_rand(10,100)); ?>">
        <link rel="stylesheet" href="https://demo.myhexa.co/short/admin/install_assets/font-awesome/css/font-awesome.min.css?<?php echo(mt_rand(10,100)); ?>">
		    <link rel="stylesheet" href="https://demo.myhexa.co/short/admin/install_assets/css/form-elements.css?<?php echo(mt_rand(10,100)); ?>">
        <link rel="stylesheet" href="https://demo.myhexa.co/short/admin/install_assets/css/style.css?<?php echo(mt_rand(10,100)); ?>">
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body style="margin-top:1.7em">
        <div class="top-content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 text">
                        <img src="https://myhexa.co/assets/img/sunset-full.png" alt="" width="177px">
                        <div class="description">
                       	    <p style="color:#1d2531">
                              We know you're going to love Sunset. In a minute, you'll be able to start using it.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3 form-box">
                    	<form role="form" method="post" class="f1">
                    		

                    		
                    		                    		<fieldset>
                    		                    		    <h3>Welcome!</h3>
                    		<p>Thank you for choosing Sunset. In a few moments, you'll have the ability to install Sunset on your server. The process should take less than 60 seconds and the requirements are super simple.<br><br>
                    		<b>You'll need:</b><br>
                    		- MySQL Database<br>
                    		- MySQL DB User<br>
                    		- MySQL DB Password
                    		</p><br>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-next">Start</button>
                                </div>
                            </fieldset>
                            
                            
                    		<fieldset>
                    		    <h3>Account Details</h3>
                    		<p>These are the credentials you will use to log into Sunset.</p><br>
                    		<div class="form-group form-inline">
                                    <input type="text" name="ufirst" placeholder="First Name" class="f1-last-name form-control" id="f1-last-name">
                                    <input type="text" name="ulast" placeholder="Last Name" class="f1-last-name form-control" id="f1-last-name">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="uusername" placeholder="Username" class="f1-last-name form-control" id="f1-last-name">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="uemail" placeholder="Email Address" class="f1-last-name form-control" id="f1-last-name">
                                </div>
                                <div class="form-group">
                                    <input placeholder="pass" class="form-control" disabled>
                                    <p>(Above is your password. Make sure to change it after you install.) </p>
                                </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous">Back</button>
                                    <button type="button" class="btn btn-next">Continue</button>
                                </div>
                            </fieldset>

                            <fieldset>
                                <h3>Database Details</h3>
                    		<p>These are the credentials that will connect your site to your database.</p><br>
                    		<div class="form-group">
                                  <input type="text" name="db_host" value="localhost" class="f1-last-name form-control" placeholder="Database Host" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <input type="text" name="db_name" class="f1-last-name form-control" placeholder="Database Name" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <input type="text" name="db_user" class="f1-last-name form-control" placeholder="Database User" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <input type="password" name="db_password" class="f1-last-name form-control" placeholder="Database Password" id="f1-last-name">
                              </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous">Back</button>
                                    <button type="button" class="btn btn-next">Continue</button>
                                </div>
                            </fieldset>
                            
                            <fieldset>
                                <h3>Site Details</h3>
                    		<p>These are the required fields to make your site run.</p><br>
                    		<div class="form-group">
                    		    Site Name:
                                  <input type="text" name="title" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                    		    Site URL:
                                  <input type="text" value="<?php
                                   $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; echo $actual_link;
                                   ?>" name="url" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                    		    Contact Email:
                                  <input type="email" name="cemail" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                    		    Accent Color:
                                  <input type="text" name="color" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                    		    Logo URL:
                                  <input type="text" name="logo" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous">Back</button>
                                    <button type="submit" class="btn btn-submit">Finish</button>
                                </div>
                            </fieldset>
                    	</form>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://demo.myhexa.co/short/admin/install_assets/js/jquery-1.11.1.min.js?<?php echo(mt_rand(10,100)); ?>"></script>
        <script src="https://demo.myhexa.co/short/admin/install_assets/bootstrap/js/bootstrap.min.js?<?php echo(mt_rand(10,100)); ?>"></script>
        <script src="https://demo.myhexa.co/short/admin/install_assets/js/jquery.backstretch.min.js?<?php echo(mt_rand(10,100)); ?>"></script>
        <script src="https://demo.myhexa.co/short/admin/install_assets/js/retina-1.1.0.min.js?<?php echo(mt_rand(10,100)); ?>"></script>
        <script src="https://demo.myhexa.co/short/admin/install_assets/js/scripts.js?<?php echo(mt_rand(10,100)); ?>"></script>
        <!--[if lt IE 10]>
            <script src="https://demo.myhexa.co/short/admin/install_assets/js/placeholder.js"></script>
        <![endif]-->
    </body>
</html>
